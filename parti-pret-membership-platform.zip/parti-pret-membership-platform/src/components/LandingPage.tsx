
import logoPret from "../assets/PRET.jpeg";
import { FooterPrivacy } from './FooterPrivacy';


import {
  User, MapPin, CreditCard, ShieldCheck, ArrowRight,
  Globe2, Heart, TrendingUp, Sparkles, Search, Wallet, Lock, Clock, BadgeCheck,
} from 'lucide-react';

export default function LandingPage({
  onJoin, onAdmin, onTreasurer, onTrack,
}: {
  onJoin: () => void;
  onAdmin: () => void;
  onTreasurer: () => void;
  onTrack: () => void;
}) {

  
  return (
    

    <div className="min-h-screen bg-slate-50">
      {/* Nav */}
      <nav className="sticky top-0 z-40 bg-white/80 backdrop-blur-lg border-b border-slate-100">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
                         <img src={logoPret} alt="Logo" className="h-9 w-auto object-contain rounded-lg" />

            <span className="font-display font-extrabold text-lg text-slate-900">Parti PRET</span>
          </div>
          <div className="flex items-center gap-1 sm:gap-2">
            <button onClick={onTrack} className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-slate-600 font-semibold text-sm hover:bg-slate-100 transition-colors">
              <Search className="w-4 h-4" /> Suivi
            </button>
            
            <button onClick={onJoin} className="pret-btn-primary text-sm py-2">
              Adhérer
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 pret-gradient" />
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: 'radial-gradient(circle at 20% 30%, white 1px, transparent 1px), radial-gradient(circle at 80% 70%, white 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }} />

        <div className="relative max-w-6xl mx-auto px-4 py-20 md:py-28 text-center text-white">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur border border-white/20 text-sm font-medium mb-6 animate-fade-in-up">
            <Sparkles className="w-4 h-4 text-blue-200" />
            PARTI PRET

          </div>
          <h1 className="text-4xl md:text-6xl font-display font-extrabold leading-tight mb-6 animate-fade-in-up" style={{ animationDelay: '0.05s' }}>
            Ensemble, bâtissons<br />
            <span className="text-blue-200">l'avenir du PRET</span>
          </h1>
          <p className="text-lg md:text-xl text-blue-50 max-w-2xl mx-auto mb-10 animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
            Rejoignez les milliers de militants qui croient en un avenir meilleur, partout dans le monde. L'adhésion prend 2 minutes.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up" style={{ animationDelay: '0.15s' }}>
            <button onClick={onJoin} className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-white text-blue-700 font-bold text-lg hover:shadow-2xl hover:-translate-y-0.5 transition-all">
              J'adhère au Parti PRET
              <ArrowRight className="w-5 h-5" />
            </button>
            <button onClick={onTrack} className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-white/10 backdrop-blur border border-white/20 text-white font-bold text-lg hover:bg-white/20 transition-all">
              <Search className="w-5 h-5" />
              Suivre ma demande
            </button>
           <button
  onClick={onTrack}
  className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-blur-md bg-[#0033CC] text-white font-bold hover:bg-blue-700 transition"
>
  Télécharger ma carte
</button>


          </div>
        </div>

        <svg className="block w-full" viewBox="0 0 1440 60" preserveAspectRatio="none" style={{ height: '40px' }}>
          <path d="M0,30 C480,60 960,0 1440,30 L1440,60 L0,60 Z" fill="#f8fafc" />
        </svg>
      </section>

      {/* Steps */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-display font-extrabold text-slate-900 mb-3">Comment adhérer ?</h2>
          <p className="text-slate-500">Un processus simple en 5 étapes</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          {[
            { icon: User, title: '1. Infos personnelles', desc: 'Nom, prénom, sexe, date de naissance, téléphone, profession.' },
            { icon: MapPin, title: '2. Localisation', desc: 'Pays, ville, adresse, lieu de vote — en texte libre.' },
            { icon: BadgeCheck, title: '3. Identité', desc: 'Photo, document d\'identité et son numéro.' },
            { icon: CreditCard, title: '4. Paiement', desc: 'Wave ou Orange Money avec référence.' },
            { icon: ShieldCheck, title: '5. Consentement', desc: 'Acceptation de la politique de confidentialité.' },
          ].map((s, i) => (
            <div key={i} className="pret-card p-5 hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 animate-fade-in-up" style={{ animationDelay: `${i * 0.05}s` }}>
              <div className="w-11 h-11 rounded-xl bg-blue-50 flex items-center justify-center mb-3">
                <s.icon className="w-5 h-5 text-blue-600" />
              </div>
              <h3 className="font-display font-bold text-slate-900 text-sm mb-1.5">{s.title}</h3>
              <p className="text-xs text-slate-500">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Workflow */}
      <section className="bg-white border-y border-slate-100 py-16">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-display font-extrabold text-slate-900 mb-3">Le parcours d'adhésion</h2>
            <p className="text-slate-500">De la soumission à la carte de membre</p>
          </div>
          <div className="space-y-3">
            {[
              { label: 'Soumission du formulaire', desc: 'Le militant remplit le formulaire en ligne', icon: User },
              { label: 'Statut: En attente', desc: 'La demande est enregistrée avec le statut "pending"', icon: Clock },
              { label: 'Validation du paiement', desc: 'Le Trésorier valide manuellement le paiement', icon: Wallet },
              { label: 'Validation de l\'adhésion', desc: 'L\'Administrateur valide l\'adhésion du membre', icon: ShieldCheck },
              { label: 'Génération du numéro de membre', desc: 'Un numéro unique est généré automatiquement', icon: TrendingUp },
              { label: 'Génération du QR code & carte PDF', desc: ' le QR code et la carte', icon: BadgeCheck },
              { label: 'Notification envoyée', desc: 'Le membre est notifié de la confirmation', icon: Sparkles },
            ].map((step, i) => (
              <div key={i} className="flex items-center gap-4 animate-fade-in-up" style={{ animationDelay: `${i * 0.04}s` }}>
                <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center shrink-0">
                  <step.icon className="w-5 h-5 text-blue-600" />
                </div>
                <div className="flex-1 pret-card p-4">
                  <p className="font-semibold text-slate-800 text-sm">{step.label}</p>
                  <p className="text-sm text-slate-500">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portals */}
      

      {/* Values */}
      <section className="bg-white border-y border-slate-100 py-16">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Globe2, title: 'Présence mondiale', desc: 'Des militants sur tous les continents. Où que vous viviez, vous pouvez adhérer.' },
              { icon: Heart, title: 'Engagement citoyen', desc: 'Un mouvement porté par la passion et la conviction d\'un avenir meilleur.' },
              { icon: Lock, title: 'Données protégées', desc: 'Vos informations sont sécurisées et utilisées uniquement pour votre adhésion.' },
            ].map((v, i) => (
              <div key={i} className="text-center animate-fade-in-up" style={{ animationDelay: `${i * 0.08}s` }}>
                <div className="w-14 h-14 rounded-2xl pret-gradient mx-auto flex items-center justify-center mb-4 shadow-lg shadow-blue-600/20">
                  <v.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="font-display font-bold text-lg text-slate-900 mb-2">{v.title}</h3>
                <p className="text-slate-500 text-sm max-w-xs mx-auto">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-4xl mx-auto px-4 py-20 text-center">
        <h2 className="text-3xl md:text-4xl font-display font-extrabold text-slate-900 mb-4">Prêt à faire la différence ?</h2>
        <p className="text-slate-500 mb-8 max-w-xl mx-auto">Chaque adhésion compte. Rejoignez le Parti PRET et soyez acteur du changement.</p>
        <button onClick={onJoin} className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl pret-gradient text-white font-bold text-lg hover:shadow-2xl hover:-translate-y-0.5 transition-all">
          Adhérer maintenant
          <ArrowRight className="w-5 h-5" />
        </button>
      </section>

      {/* Footer */}
     <FooterPrivacy />

    </div>
  );
}

function PortalCard({ icon: Icon, title, desc, onClick }: { icon: React.ComponentType<{ className?: string }>; title: string; desc: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="pret-card p-6 text-left hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 group">
      <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center mb-4 group-hover:pret-gradient transition-all">
        <Icon className="w-6 h-6 text-blue-600 group-hover:text-white transition-colors" />
      </div>
      <h3 className="font-display font-bold text-lg text-slate-900 mb-2">{title}</h3>
      <p className="text-sm text-slate-500">{desc}</p>
      <div className="mt-4 inline-flex items-center gap-1 text-blue-600 text-sm font-semibold">
        Accéder <ArrowRight className="w-4 h-4" />
      </div>
    </button>
  );
}


