import { useState } from 'react';
import { supabase, type MemberInput, type IdDocType } from '../lib/supabase';
import { CountrySelect } from 'react-country-state-city';
import 'react-country-state-city/dist/react-country-state-city.css';
import {
  User, MapPin, Upload, CreditCard, Check, ChevronRight,
  ChevronLeft, CheckCircle2, AlertCircle, Loader2, Mail, Phone,
  Globe, FileCheck, ShieldCheck, Calendar, Briefcase, Vote,
  FileText, Lock, BadgeCheck,
} from 'lucide-react';

const STEPS = [
  { id: 1, title: 'Infos personnelles', subtitle: 'Qui êtes-vous ?', icon: User },
  { id: 2, title: 'Localisation', subtitle: 'Où vivez-vous ?', icon: MapPin },
  { id: 3, title: 'Identité', subtitle: 'Vérification', icon: BadgeCheck },
  { id: 4, title: 'Paiement', subtitle: 'Cotisation', icon: CreditCard },
  { id: 5, title: 'Consentement', subtitle: 'Validation', icon: ShieldCheck },
];

const ID_DOC_TYPES: IdDocType[] = ['CNI', 'Passeport', 'Permis de conduire', 'Autre'];

const emptyForm: MemberInput = {
  first_name: '',
  last_name: '',
  sex: 'Homme',
  date_of_birth: '',
  phone: '',
  email: '',
  profession: '',
  country: '',
  city: '',
  address: '',
  voting_location: '',
  political_section: '',
  id_photo_url: null,
  id_document_url: null,
  id_document_type: null,
  id_document_number: '',
  payment_method: 'Wave',
  payment_reference: '',
  consent_accepted: false,
};

export default function MembershipForm({ onDone }: { onDone: () => void }) {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState<MemberInput>(emptyForm);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [docFile, setDocFile] = useState<File | null>(null);
  const [docPreview, setDocPreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  function update<K extends keyof MemberInput>(key: K, value: MemberInput[K]) {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: '' }));
  }

  function validateStep(s: number): boolean {
    const e: Record<string, string> = {};
    if (s === 1) {
      if (!form.first_name.trim()) e.first_name = 'Le prénom est requis';
      if (!form.last_name.trim()) e.last_name = 'Le nom est requis';
      if (!form.date_of_birth) e.date_of_birth = 'La date de naissance est requise';
      if (form.date_of_birth) {
  const birthDate = new Date(form.date_of_birth);
  const today = new Date();

  today.setHours(23, 59, 59, 999);

  if (birthDate > today) {
    e.date_of_birth = 'La date de naissance ne peut pas être dans le futur';
  }
  const minBirthDate = new Date();
  minBirthDate.setFullYear(minBirthDate.getFullYear() - 18);

  if (birthDate > minBirthDate) {
    e.date_of_birth = 'Vous devez avoir au moins 18 ans pour adhérer';
  }

}
      if (!form.phone.trim()) e.phone = 'Le téléphone est requis';
      if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Email invalide';
    }
    if (s === 2) {
      if (!form.country.trim()) e.country = 'Le pays est requis';
      if (!form.city.trim()) e.city = 'La ville est requise';
    }
    if (s === 3) {
      if (!photoFile && !form.id_photo_url) e.photo = 'La photo est requise';
      if (!docFile && !form.id_document_url) e.id_document = 'Le document est requis';
      if (!form.id_document_type) e.id_document_type = 'Le type de document est requis';
      if (!form.id_document_number?.trim()) e.id_document_number = 'Le numéro est requis';
    }
    if (s === 4) {
      if (!form.payment_reference.trim()) e.payment_reference = 'La référence est requise';
    }
    if (s === 5) {
      if (!form.consent_accepted) e.consent = 'Vous devez accepter la politique de confidentialité';
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function next() {
    if (validateStep(step)) setStep((s) => Math.min(s + 1, 5));
  }

  function back() {
    setStep((s) => Math.max(s - 1, 1));
  }

  async function uploadFile(file: File, bucket: string): Promise<string | null> {
    try {
      const ext = file.name.split('.').pop() || 'jpg';
      const fileName = `${bucket}-${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
      const { error } = await supabase.storage
        .from(bucket)
        .upload(fileName, file, { cacheControl: '3600', upsert: false });
      if (error) throw error;
      const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(fileName);
      return urlData.publicUrl;
    } catch {
      return null;
    }
  }

  async function handleSubmit() {
    if (!validateStep(5)) return;
    setSubmitting(true);
    setSubmitError(null);

    let photoUrl = form.id_photo_url;
    let docUrl = form.id_document_url;

    setUploading(true);
    if (photoFile) {
      photoUrl = await uploadFile(photoFile, 'member-photos');
      if (!photoUrl) {
        setSubmitError('Erreur lors du téléversement de la photo.');
        setUploading(false);
        setSubmitting(false);
        return;
      }
    }
    if (docFile) {
      docUrl = await uploadFile(docFile, 'identity-documents');
      if (!docUrl) {
        setSubmitError('Erreur lors du téléversement du document.');
        setUploading(false);
        setSubmitting(false);
        return;
      }
    }
    setUploading(false);

    const payload = { ...form, id_photo_url: photoUrl, id_document_url: docUrl };

    console.log('[MembershipForm] Payload to insert:', payload);
    console.log('[MembershipForm] Insert started...');

    const { data, error } = await supabase.from('members').insert(payload);

    console.log('[MembershipForm] Supabase response:', data);
    console.log('[MembershipForm] Supabase error object:', error);

    if (error) {
      console.log('[MembershipForm] Insert FAILED:', error.message, error.code, error.details, error.hint);
      setSubmitError(error.message || 'Erreur lors de l\'envoi du formulaire.');
      setSubmitting(false);
      return;
    }

    console.log('[MembershipForm] Insert SUCCEEDED — row added to members table.');

// Notification Resend
try {
  const notificationResponse = await fetch('/api/notifier', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      first_name: payload.first_name,
      last_name: payload.last_name,
      phone: payload.phone,
      email: payload.email,
      payment_method: payload.payment_method,
      payment_reference: payload.payment_reference,
    }),
  });

  if (!notificationResponse.ok) {
    const notificationError = await notificationResponse.json().catch(() => ({}));
    console.error(
      '[MembershipForm] Resend notification failed:',
      notificationError
    );
  } else {
    console.log('[MembershipForm] Resend notification sent successfully.');
  }
} catch (notificationError) {
  console.error(
    '[MembershipForm] Error while sending notification:',
    notificationError
  );
}

setSubmitting(false);
setSubmitted(true);
  }

  if (submitted) return <SuccessScreen onDone={onDone} />;

  return (
    <div className="min-h-screen pret-gradient-soft py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8 animate-fade-in-up">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-sm font-semibold mb-4">
            <CheckCircle2 className="w-4 h-4" />
            Parti PRET
          </div>
          <h1 className="text-3xl md:text-4xl font-display font-extrabold text-slate-900 mb-2">
            Rejoignez le mouvement
          </h1>
          <p className="text-slate-500">Adhérez au Parti PRET en 5 étapes simples.</p>
        </div>

        {/* Progress */}
        <div className="mb-8 animate-fade-in-up" style={{ animationDelay: '0.05s' }}>
          <div className="flex items-center justify-between mb-2">
            {STEPS.map((s, i) => (
              <div key={s.id} className="flex items-center flex-1 last:flex-none">
                <div className="flex flex-col items-center gap-1.5">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm transition-all duration-300 ${
                      step > s.id
                        ? 'pret-gradient text-white shadow-lg shadow-blue-600/30'
                        : step === s.id
                        ? 'pret-gradient text-white shadow-lg shadow-blue-600/30 scale-110'
                        : 'bg-white text-slate-400 border border-slate-200'
                    }`}
                  >
                    {step > s.id ? <Check className="w-5 h-5" /> : s.id}
                  </div>
                  <span className={`text-xs font-medium hidden sm:block ${step >= s.id ? 'text-slate-800' : 'text-slate-400'}`}>
                    {s.title}
                  </span>
                </div>
                {i < STEPS.length - 1 && (
                  <div className={`flex-1 h-0.5 mx-2 rounded-full transition-all duration-300 ${step > s.id ? 'bg-blue-600' : 'bg-slate-200'}`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Card */}
        <div className="pret-card p-6 md:p-8 animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
          <div className="mb-6">
            <div className="flex items-center gap-3 mb-1">
              <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
                {(() => { const Icon = STEPS[step - 1].icon; return <Icon className="w-5 h-5 text-blue-600" />; })()}
              </div>
              <div>
                <h2 className="text-xl font-display font-bold text-slate-900">{STEPS[step - 1].title}</h2>
                <p className="text-sm text-slate-500">{STEPS[step - 1].subtitle}</p>
              </div>
            </div>
          </div>

          <div key={step} className="animate-slide-in-right">
            {step === 1 && <StepPersonal form={form} errors={errors} update={update} />}
            {step === 2 && <StepLocation form={form} errors={errors} update={update} />}
            {step === 3 && (
              <StepIdentity
                form={form}
                errors={errors}
                update={update}
                photoPreview={photoPreview}
                docPreview={docPreview}
                onPhotoChange={(f) => { setPhotoFile(f); setPhotoPreview(URL.createObjectURL(f)); setErrors((e) => ({ ...e, photo: '' })); }}
                onDocChange={(f) => { setDocFile(f); setDocPreview(URL.createObjectURL(f)); setErrors((e) => ({ ...e, id_document: '' })); }}
              />
            )}
            {step === 4 && <StepPayment form={form} errors={errors} update={update} />}
            {step === 5 && <StepConsent form={form} errors={errors} update={update} />}
          </div>

          {submitError && (
            <div className="mt-4 flex items-start gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm animate-fade-in">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{submitError}</span>
            </div>
          )}

          <div className="flex items-center justify-between mt-8 pt-6 border-t border-slate-100">
            {step > 1 ? (
              <button onClick={back} className="pret-btn-ghost">
                <ChevronLeft className="w-4 h-4" />
                Retour
              </button>
            ) : (
  <button onClick={onDone} className="pret-btn-ghost">
    <ChevronLeft className="w-4 h-4" />
    Retour
  </button>
)}
            {step < 5 ? (
              <button onClick={next} className="pret-btn-primary">
                Continuer
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button onClick={handleSubmit} disabled={submitting || uploading} className="pret-btn-primary">
                {submitting || uploading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    {uploading ? 'Téléversement...' : 'Envoi...'}
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    Valider mon adhésion
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        <p className="text-center text-xs text-slate-400 mt-6">
          Vos données sont protégées et utilisées uniquement pour l'adhésion au Parti PRET.
        </p>
      </div>
    </div>
  );
}

/* ── Step 1 ──────────────────────────────────────────────────── */

function StepPersonal({
  form, errors, update,
}: {
  form: MemberInput;
  errors: Record<string, string>;
  update: <K extends keyof MemberInput>(k: K, v: MemberInput[K]) => void;
}) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="pret-label">Prénom</label>
          <input className={`pret-input ${errors.first_name ? 'pret-input-error' : ''}`} value={form.first_name} onChange={(e) => update('first_name', e.target.value)} placeholder="Ex: Mariam" />
          {errors.first_name && <ErrorText msg={errors.first_name} />}
        </div>
        <div>
          <label className="pret-label">Nom</label>
          <input className={`pret-input ${errors.last_name ? 'pret-input-error' : ''}`} value={form.last_name} onChange={(e) => update('last_name', e.target.value)} placeholder="Ex: Diallo" />
          {errors.last_name && <ErrorText msg={errors.last_name} />}
        </div>
      </div>

      <div>
        <label className="pret-label">Sexe</label>
        <div className="grid grid-cols-3 gap-3">
          {(['Homme', 'Femme'] as const).map((s) => (
            <button key={s} type="button" onClick={() => update('sex', s)}
              className={`px-4 py-3 rounded-xl font-semibold transition-all duration-200 border-2 ${form.sex === s ? 'border-blue-600 bg-blue-50 text-blue-700' : 'border-slate-200 bg-white text-slate-500 hover:border-slate-300'}`}>
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
  <label className="pret-label">Date de naissance</label>
  <div className="relative">
    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />

    <input
      type="date"
      max={new Date().toISOString().split('T')[0]}
      className={`pret-input pl-10 ${errors.date_of_birth ? 'pret-input-error' : ''}`}
      value={form.date_of_birth || ''}
      onChange={(e) => update('date_of_birth', e.target.value)}
    />
  </div>

  {errors.date_of_birth && <ErrorText msg={errors.date_of_birth} />}
</div>
        <div>
          <label className="pret-label">Téléphone</label>
<div className="relative">
  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
  <input
    type="tel"
    inputMode="numeric"
    autoComplete="tel"
    className={`pret-input pl-10 ${errors.phone ? 'pret-input-error' : ''}`}
    value={form.phone}
    onChange={(e) =>
      update(
        'phone',
        e.target.value.replace(/[^\d+]/g, '')
      )
    }
    placeholder="+221771234567"
  />
</div>
{errors.phone && <ErrorText msg={errors.phone} />}
        </div>
      </div>

      <div>
        <label className="pret-label">Email <span className="text-slate-400 font-normal">(optionnel)</span></label>
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input type="email" className={`pret-input pl-10 ${errors.email ? 'pret-input-error' : ''}`} value={form.email || ''} onChange={(e) => update('email', e.target.value)} placeholder="mariam.diallo@email.com" />
        </div>
        {errors.email && <ErrorText msg={errors.email} />}
      </div>

      <div>
        <label className="pret-label">Profession</label>
        <div className="relative">
          <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input className="pret-input pl-10" value={form.profession || ''} onChange={(e) => update('profession', e.target.value)} placeholder="Ex: Enseignant, Commerçant..." />
        </div>
      </div>
    </div>
  );
}

/* ── Step 2 ──────────────────────────────────────────────────── */

function StepLocation({
  form, errors, update,
}: {
  form: MemberInput;
  errors: Record<string, string>;
  update: <K extends keyof MemberInput>(k: K, v: MemberInput[K]) => void;
}) {
  return (
    <div className="space-y-4">
      <div className="flex items-start gap-2 p-3 rounded-xl bg-blue-50 border border-blue-100 text-blue-700 text-sm mb-2">
        <Globe className="w-4 h-4 mt-0.5 shrink-0" />
        <span>Les militants du Parti PRET sont partout dans le monde. Saisissez librement votre localisation.</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
       <div>
  <label className="pret-label">Pays</label>

  <CountrySelect
    onChange={(country: any) => {
      update('country', country.name);
    }}
    placeHolder="Sélectionnez votre pays"
    showFlag={true}
    containerClassName="w-full" 
  />

  {errors.country && <ErrorText msg={errors.country} />}
</div>
        <div>
          <label className="pret-label">Ville</label>
          <input className={`pret-input ${errors.city ? 'pret-input-error' : ''}`} value={form.city} onChange={(e) => update('city', e.target.value)} placeholder="Ex: Dakar, Paris..." />
          {errors.city && <ErrorText msg={errors.city} />}
        </div>
      </div>

      <div>
        <label className="pret-label">Adresse physique</label>
        <input className="pret-input" value={form.address || ''} onChange={(e) => update('address', e.target.value)} placeholder="Ex: 123 Rue de l'Indépendance" />
      </div>

      <div>
        <label className="pret-label">Lieu de vote</label>
        <div className="relative">
          <Vote className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input className="pret-input pl-10" value={form.voting_location || ''} onChange={(e) => update('voting_location', e.target.value)} placeholder="Ex: Bureau de vote Dakar-Plateau" />
        </div>
      </div>

      <div>
        <label className="pret-label">Section politique <span className="text-slate-400 font-normal">(optionnel)</span></label>
        <input className="pret-input" value={form.political_section || ''} onChange={(e) => update('political_section', e.target.value)} placeholder="Ex: Section Jeunesse, Section Femmes..." />
      </div>
    </div>
  );
}

/* ── Step 3 ──────────────────────────────────────────────────── */

function StepIdentity({
  form, errors, update, photoPreview, docPreview, onPhotoChange, onDocChange,
}: {
  form: MemberInput;
  errors: Record<string, string>;
  update: <K extends keyof MemberInput>(k: K, v: MemberInput[K]) => void;
  photoPreview: string | null;
  docPreview: string | null;
  onPhotoChange: (f: File) => void;
  onDocChange: (f: File) => void;
}) {
  return (
    <div className="space-y-5">
      {/* Photo */}
      <div>
        <label className="pret-label">Photo du membre</label>
        <label className={`block cursor-pointer rounded-2xl border-2 border-dashed transition-all duration-200 p-6 text-center hover:bg-blue-50/50 ${errors.photo ? 'border-red-300' : 'border-slate-300 hover:border-blue-500'}`}>
          <input type="file" accept="image/jpeg,image/png,image/jpg" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) onPhotoChange(f); }} />
          {photoPreview ? (
            <div className="flex flex-col items-center gap-2">
              <img src={photoPreview} alt="Aperçu" className="w-28 h-28 rounded-xl object-cover border-2 border-blue-200 shadow-lg" />
              <span className="text-sm font-semibold text-blue-600 flex items-center gap-1"><CheckCircle2 className="w-4 h-4" /> Photo sélectionnée — cliquez pour changer</span>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center"><Upload className="w-5 h-5 text-blue-600" /></div>
              <span className="font-semibold text-slate-700 text-sm">Cliquez pour téléverser votre photo</span>
              <span className="text-xs text-slate-400">JPG, PNG — 5 Mo max</span>
            </div>
          )}
        </label>
        {errors.photo && <ErrorText msg={errors.photo} />}
      </div>

      {/* Document */}
      <div>
        <label className="pret-label">Document d'identité</label>
        <label className={`block cursor-pointer rounded-2xl border-2 border-dashed transition-all duration-200 p-6 text-center hover:bg-blue-50/50 ${errors.id_document ? 'border-red-300' : 'border-slate-300 hover:border-blue-500'}`}>
          <input type="file" accept="image/jpeg,image/png,image/jpg,application/pdf" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) onDocChange(f); }} />
          {docPreview ? (
            <div className="flex flex-col items-center gap-2">
              {docPreview.startsWith('data:application/pdf') ? (
                <FileText className="w-12 h-12 text-blue-500" />
              ) : (
                <img src={docPreview} alt="Aperçu document" className="max-h-28 rounded-xl border-2 border-blue-200 shadow-lg object-contain" />
              )}
              <span className="text-sm font-semibold text-blue-600 flex items-center gap-1"><CheckCircle2 className="w-4 h-4" /> Document sélectionné — cliquez pour changer</span>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center"><FileText className="w-5 h-5 text-blue-600" /></div>
              <span className="font-semibold text-slate-700 text-sm">Cliquez pour téléverser votre document</span>
              <span className="text-xs text-slate-400">JPG, PNG, PDF — 5 Mo max</span>
            </div>
          )}
        </label>
        {errors.id_document && <ErrorText msg={errors.id_document} />}
      </div>

      {/* Doc type + number */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="pret-label">Type de document</label>
          <div className="grid grid-cols-2 gap-2">
            {ID_DOC_TYPES.map((t) => (
              <button key={t} type="button" onClick={() => update('id_document_type', t)}
                className={`px-3 py-2.5 rounded-lg text-sm font-semibold transition-all border-2 ${form.id_document_type === t ? 'border-blue-600 bg-blue-50 text-blue-700' : 'border-slate-200 bg-white text-slate-500 hover:border-slate-300'}`}>
                {t}
              </button>
            ))}
          </div>
          {errors.id_document_type && <ErrorText msg={errors.id_document_type} />}
        </div>
        <div>
          <label className="pret-label">Numéro du document</label>
          <input className={`pret-input ${errors.id_document_number ? 'pret-input-error' : ''}`} value={form.id_document_number || ''} onChange={(e) => update('id_document_number', e.target.value)} placeholder="Ex: 123456789" />
          {errors.id_document_number && <ErrorText msg={errors.id_document_number} />}
        </div>
      </div>

      <div className="flex items-start gap-2 p-3 rounded-xl bg-amber-50 border border-amber-100 text-amber-700 text-sm">
        <FileCheck className="w-4 h-4 mt-0.5 shrink-0" />
        <span>Vérifiez que la photo et le document sont nets et lisibles.</span>
      </div>
    </div>
  );
}

/* ── Step 4 ──────────────────────────────────────────────────── */

function StepPayment({
  form, errors, update,
}: {
  form: MemberInput;
  errors: Record<string, string>;
  update: <K extends keyof MemberInput>(k: K, v: MemberInput[K]) => void;
}) {
  return (
    <div className="space-y-5">
      <div>
        <label className="pret-label">Mode de paiement</label>
        <div className="grid grid-cols-2 gap-3">
          <PaymentCard active={form.payment_method === 'Wave'} onClick={() => update('payment_method', 'Wave')} name="Wave" color="from-blue-500 to-blue-600" />
          <PaymentCard active={form.payment_method === 'Orange Money'} onClick={() => update('payment_method', 'Orange Money')} name="Orange Money" color="from-orange-500 to-orange-600" />
        </div>
      </div>

      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
        <p className="text-sm text-slate-600">
          Effectuez votre paiement via ce numero 00221783009109 au nom de ELHADJ IBRAHIMA TOURE  <strong>{form.payment_method}</strong>, puis saisissez la référence de la transaction ci-dessous.
        </p>
      </div>

      <div>
        <label className="pret-label">Référence de paiement</label>
        <input className={`pret-input ${errors.payment_reference ? 'pret-input-error' : ''}`} value={form.payment_reference} onChange={(e) => update('payment_reference', e.target.value)} placeholder="Ex: TXN123456789" />
        {errors.payment_reference && <ErrorText msg={errors.payment_reference} />}
      </div>
    </div>
  );
}

function PaymentCard({ active, onClick, name, color }: { active: boolean; onClick: () => void; name: string; color: string }) {
  return (
    <button type="button" onClick={onClick}
      className={`relative p-4 rounded-xl border-2 transition-all duration-200 text-left ${active ? 'border-blue-600 shadow-lg shadow-blue-600/10' : 'border-slate-200 hover:border-slate-300'}`}>
      <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${color} mb-2`} />
      <span className="font-semibold text-slate-800 text-sm">{name}</span>
      {active && <div className="absolute top-2 right-2 w-5 h-5 rounded-full pret-gradient flex items-center justify-center"><Check className="w-3 h-3 text-white" /></div>}
    </button>
  );
}

/* ── Step 5 ──────────────────────────────────────────────────── */

function StepConsent({
  form, errors, update,
}: {
  form: MemberInput;
  errors: Record<string, string>;
  update: <K extends keyof MemberInput>(k: K, v: MemberInput[K]) => void;
}) {
  return (
    <div className="space-y-5">
      <div className="flex items-start gap-3 p-4 rounded-xl bg-blue-50 border border-blue-100">
        <Lock className="w-5 h-5 text-blue-600 mt-0.5 shrink-0" />
        <div>
          <h3 className="font-semibold text-slate-800 text-sm mb-1">Protection de vos données</h3>
          <p className="text-sm text-slate-600">
            Le Parti PRET s'engage à protéger vos données personnelles conformément à la loi.
            Vos informations seront utilisées uniquement pour la gestion de votre adhésion.
          </p>
        </div>
      </div>

      <label className={`flex items-start gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all duration-200 ${form.consent_accepted ? 'border-blue-600 bg-blue-50' : errors.consent ? 'border-red-300' : 'border-slate-200 hover:border-slate-300'}`}>
        <input type="checkbox" className="mt-0.5 w-5 h-5 rounded accent-blue-600 shrink-0" checked={form.consent_accepted} onChange={(e) => update('consent_accepted', e.target.checked)} />
        <span className="text-sm text-slate-700 leading-relaxed">
          Je certifie que les informations fournies sont exactes et j'accepte que le Parti PRET traite mes données dans le cadre de mon adhésion conformément à sa politique de confidentialité.
        </span>
      </label>
      {errors.consent && <ErrorText msg={errors.consent} />}

      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
        <h4 className="font-semibold text-slate-700 text-sm">Récapitulatif du processus</h4>
        <ol className="text-sm text-slate-500 space-y-1 list-decimal list-inside">
          <li>Soumission de votre demande (statut: en attente)</li>
          <li>Validation du paiement par le Trésorier</li>
          <li>Validation de l'adhésion par l'Administrateur</li>
          <li>Génération de votre numéro de membre, QR code et carte de membre</li>
          <li>Notification de confirmation</li>
        </ol>
      </div>
    </div>
  );
}

/* ── Success ──────────────────────────────────────────────────── */

function SuccessScreen({ onDone }: { onDone: () => void }) {
  return (
    <div className="min-h-screen pret-gradient-soft flex items-center justify-center px-4">
      <div className="max-w-md text-center animate-fade-in-up">
        <div className="w-20 h-20 rounded-full pret-gradient mx-auto flex items-center justify-center mb-6 shadow-xl shadow-blue-600/30">
          <CheckCircle2 className="w-10 h-10 text-white" />
        </div>
        <h1 className="text-3xl font-display font-extrabold text-slate-900 mb-3">Demande envoyée !</h1>
        <p className="text-slate-500 mb-8">
          Votre demande d'adhésion au Parti PRET a été enregistrée. Elle est maintenant en attente de validation du paiement par le Trésorier. Vous pourrez suivre son statut sur la page de suivi.
        </p>
        <button onClick={onDone} className="pret-btn-primary">Retour à l'accueil</button>
      </div>
    </div>
  );
}

/* ── Shared ───────────────────────────────────────────────────── */

function ErrorText({ msg }: { msg: string }) {
  return (
    <p className="text-sm text-red-500 mt-1 flex items-center gap-1 animate-fade-in">
      <AlertCircle className="w-3.5 h-3.5" />
      {msg}
    </p>
  );
}
