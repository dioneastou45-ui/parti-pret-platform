import { useState } from 'react';
import { supabase } from '../lib/supabase';

export const EspaceMilitantAccueil = () => {
  const [emailInput, setEmailInput] = useState('');
  const [donneesMilitant, setDonneesMilitant] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleRecherche = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput) return;
    
    setLoading(true);
    setErrorMsg('');
    setDonneesMilitant(null);

    try {
     
      const { data: members, error: dbError } = await supabase
        .from('members')
        .select('first_name, last_name, admin_approved, payment_status, card_pdf_url, member_number')
        .eq('email', emailInput.toLowerCase().trim());

      if (dbError) {
        console.error(dbError);
        setErrorMsg("Erreur de connexion à la base de données.");
        return;
      }

      if (!members || members.length === 0) {
        setErrorMsg("Aucun dossier trouvé pour cette adresse email.");
        return;
      }

      const member = members[0];
      setDonneesMilitant({
        nom: `${member.first_name} ${member.last_name}`,
        statut: member.admin_approved && member.payment_status ? 'approuve' : 'en_attente',
        fichier_carte: member.card_pdf_url,
        matricule: member.member_number
      });
    } catch (err) {
      console.error(err);
      setErrorMsg("Une erreur technique est survenue.");
    } finally {
      setLoading(false);
    }
  };

  const telechargerCarteDirecte = async () => {
    if (!donneesMilitant?.fichier_carte) return;
    try {
      const urlComplete = `https://supabase.co{donneesMilitant.fichier_carte}`;
      const response = await fetch(urlComplete);
      const blob = await response.blob();
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = `Carte_PRET_${donneesMilitant.matricule || 'militant'}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      alert("Erreur lors du téléchargement du fichier.");
    }
  };

  return (
    <div className="p-6 text-center max-w-sm mx-auto bg-white rounded-2xl shadow-xl border mt-10">
      <h2 className="text-xl font-bold text-gray-900 mb-4">Espace Militant</h2>

      {/* FORMULAIRE DE RECHERCHE VISUEL */}
      {!donneesMilitant && (
        <form onSubmit={handleRecherche} className="flex flex-col gap-3">
          <p className="text-xs text-gray-500 text-left">Entrez l'adresse email utilisée lors de votre inscription :</p>
          <input
            type="email"
            placeholder="votre.email@gmail.com"
            value={emailInput}
            onChange={(e) => setEmailInput(e.target.value)}
            className="p-3 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 text-black font-semibold"
            required
          />
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#0033CC] hover:bg-blue-800 text-white font-bold py-3 rounded-xl shadow transition-all disabled:opacity-50"
          >
            {loading ? "Recherche en cours..." : "Accéder à mon espace"}
          </button>
          {errorMsg && <p className="text-sm text-red-600 font-bold mt-2">{errorMsg}</p>}
        </form>
      )}

      {/* RÉSULTAT RECHERCHE */}
      {donneesMilitant && (
        <div>
          <p className="text-sm text-gray-500">Citoyen : <span className="font-bold text-gray-900">{donneesMilitant.nom}</span></p>
          
          {donneesMilitant.statut === 'approuve' && donneesMilitant.fichier_carte ? (
            <div className="mt-4">
              <p className="text-sm text-green-600 font-extrabold mb-2">🎉 VOTRE CARTE EST PRÊTE</p>
              <p className="text-xs text-gray-600 mb-4 font-mono">Matricule : {donneesMilitant.matricule}</p>
              <button 
                onClick={telechargerCarteDirecte} 
                className="w-full bg-[#0033CC] hover:bg-blue-800 text-white font-black py-3 rounded-xl shadow-lg transition-all"
              >
                TÉLÉCHARGER MA CARTE
              </button>
            </div>
          ) : (
            <div className="mt-4 p-3 bg-amber-50 rounded-xl border border-amber-200">
              <p className="text-sm text-amber-700 font-bold">⏳ Inscription en cours de validation</p>
              <p className="text-xs text-amber-600 mt-1">Votre paiement ou dossier est en cours de vérification.</p>
            </div>
          )}
          
          <button 
            onClick={() => setDonneesMilitant(null)} 
            className="text-xs text-blue-600 underline mt-4 block mx-auto hover:text-blue-800"
          >
            Rechercher un autre email
          </button>
        </div>
      )}
    </div>
  );
};
