import { jsPDF } from "jspdf";
import QRCode from "qrcode";
import logoPret from "../assets/PRET.jpeg";

import { useEffect, useState, useCallback } from 'react';
import { supabase, type Member, STATUS_LABELS, STATUS_COLORS, generateMemberNumber } from '../lib/supabase';
import {
  ShieldCheck, CheckCircle2, Clock, Search, Eye, X,
  Check, Ban, Loader2, MapPin, Phone, Mail, CreditCard, Calendar,
  UserCircle, ArrowLeft, FileText, Hash, Download,
} from 'lucide-react';

type StatusFilter = 'all' | 'pending' | 'payment_validated' | 'approved' | 'rejected';

export default function AdminDashboard({ onExit }: { onExit: () => void }) {
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [selected, setSelected] = useState<Member | null>(null);
  const [updating, setUpdating] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  
  const fetchMembers = useCallback(async () => {
    setLoading(true);
    setError(null);
    const { data, error } = await supabase.from('members').select('*').order('created_at', { ascending: false });
    if (error) setError(error.message);
    else setMembers((data as Member[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchMembers(); }, [fetchMembers]);


// 1. GENERATE MEMBERSHIP CARD 
async function generateMembershipCard(member: any, memberNumber: string) {
  try {
    const pdf = new jsPDF({
      orientation: "landscape",
      unit: "mm",
      format: [85, 54]
    });

    pdf.setFillColor(255, 255, 255);
    pdf.rect(0, 0, 85, 42, "F");

    
    pdf.setFillColor(0, 51, 204);
    pdf.rect(0, 42, 85, 12, "F");

    
    if (typeof logoPret !== 'undefined' && logoPret) {
      pdf.addImage(logoPret, "PNG", 4, 3, 11, 11);
    }
    
    pdf.setFont("Helvetica", "bold");
    pdf.setTextColor(0, 51, 204);
    pdf.setFontSize(10.5);
    pdf.text("P.R.E.T", 17, 7.5);
    
    pdf.setFont("Helvetica", "normal");
    pdf.setFontSize(5.5);
    pdf.setTextColor(100, 116, 139); 
    pdf.text("Parti Républicain de l'Équité et de la Transparence", 17, 11.5);

    
       pdf.setFont("Helvetica", "bold");
    pdf.setFontSize(3.5); 
    pdf.setTextColor(0, 0, 0); 
    pdf.text("ÉQUITÉ - TRANSPARENCE - HUMANISME", 4, 16.2); 


    if (member.id_photo_url) {
      try {
        const response = await fetch(member.id_photo_url.trim());
        const blob = await response.blob();
        const base64Photo = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(blob);
        });
        pdf.addImage(base64Photo, "JPEG", 4, 19, 16, 20, undefined, 'FAST');
      } catch (e) {
        pdf.setFillColor(241, 245, 249);
        pdf.rect(4, 19, 16, 20, "F");
      }
    } else {
      pdf.setFillColor(241, 245, 249);
      pdf.rect(4, 19, 16, 20, "F");
    }

    
    let startY = 21.5;
    const lineSpacing = 7.2;

   
    pdf.setFont("Helvetica", "normal");
    pdf.setFontSize(5);
    pdf.setTextColor(148, 163, 184);
    pdf.text("NOM & PRÉNOM", 24, startY);
    
    pdf.setFont("Helvetica", "bold");
    pdf.setFontSize(7.5);
    pdf.setTextColor(0, 0, 0);
    const fullName = `${(member.last_name || "")} ${(member.first_name || "")}`.toUpperCase();
    pdf.text(fullName, 24, startY + 3.2);

    
    pdf.setFont("Helvetica", "normal");
    pdf.setFontSize(5);
    pdf.setTextColor(148, 163, 184);
    pdf.text("N° MATRICULE", 24, startY + lineSpacing);
    
    pdf.setFont("Helvetica", "bold");
    pdf.setFontSize(7);
    pdf.setTextColor(0, 0, 0);
    pdf.text(memberNumber.toUpperCase(), 24, startY + lineSpacing + 3.2);

    // Ligne 3 : Région / Pays
    pdf.setFont("Helvetica", "normal");
    pdf.setFontSize(5);
    pdf.setTextColor(148, 163, 184);
    pdf.text("RÉGION / PAYS", 24, startY + (lineSpacing * 2));
    
    pdf.setFont("Helvetica", "bold");
    pdf.setFontSize(7);
    pdf.setTextColor(0, 0, 0);
        const currentCountry = (member.country || "SÉNÉGAL").toString().trim().toUpperCase();
    const isSeneghal = currentCountry === "SÉNÉGAL" || currentCountry === "SENEGAL";
    
    
    const currentCity = (member.city || "DAKAR").toString().trim().toUpperCase();
    
    const localization = isSeneghal 
      ? `${currentCity} / SÉNÉGAL`
      : `DIASPORA / ${currentCountry}`;

    pdf.text(localization, 24, startY + (lineSpacing * 2) + 3.2);


    
    try {
      const trackingUrl = `https://notre-site/tracking/${memberNumber}`;
      const qrCodeDataUrl = await QRCode.toDataURL(trackingUrl);
      pdf.addImage(qrCodeDataUrl, "PNG", 64, 21, 16, 16);
    } catch (e) {
      pdf.rect(64, 21, 16, 16);
    }

    pdf.setFont("Helvetica", "bold");
    pdf.setTextColor(255, 255, 255);
    pdf.setFontSize(7);
    pdf.text("Bóolo Dekkil Réew mi", 42.5, 46.5, { align: "center" });
    
    pdf.setFont("Helvetica", "normal");
    pdf.setFontSize(5.5);
    pdf.text("L'ÊTRE HUMAIN AU COEUR DE LA RÉPUBLIQUE • CARTE DE MEMBRE OFFICIEL", 42.5, 50, { align: "center" });

    
    const pdfBlob = pdf.output("blob");
    const pdfName = `card-${memberNumber}.pdf`;

    const { error: uploadError } = await supabase.storage
      .from("membership-cards")
      .upload(pdfName, pdfBlob, {
        upsert: true,
        contentType: 'application/pdf'
      });

    if (uploadError) throw uploadError;

    const { data: urlData } = supabase.storage
      .from("membership-cards")
      .getPublicUrl(pdfName);

    return urlData.publicUrl;

  } catch (error) {
    console.error("Erreur de génération du PDF :", error);
    return null;
  }
}


 

async function approveMembership(member: Member) {
  setUpdating(true);
  try {
    const memberNumber = generateMemberNumber();

    const generatedPdfUrl = await generateMembershipCard(member, memberNumber);

    if (!generatedPdfUrl) {
      throw new Error("Échec de la génération ou de l'upload du PDF");
    }

    const updates = {
      status: 'approved' as const,
      member_number: memberNumber,
      membership_validated_at: new Date().toISOString(),
      card_pdf_url: generatedPdfUrl, // AJOUT CRITIQUE : Enregistre l'URL dans LE  colonne !
    };

    const { error } = await supabase.from('members').update(updates).eq('id', member.id);
    
    if (!error) {
      setMembers((ms) => ms.map((m) => (m.id === member.id ? { ...m, ...updates } : m)));
      setSelected((s) => (s && s.id === member.id ? { ...s, ...updates } : s));
    }
  } catch (error) {
    console.error("Erreur lors de l'approbation et de l'enregistrement de l'URL :", error);
  } finally {
    setUpdating(false);
  }
}


  async function rejectMembership(member: Member) {
    setUpdating(true);
    const updates = { status: 'rejected' as const };
    const { error } = await supabase.from('members').update(updates).eq('id', member.id);
    if (!error) {
      setMembers((ms) => ms.map((m) => (m.id === member.id ? { ...m, ...updates } : m)));
      setSelected((s) => (s && s.id === member.id ? { ...s, ...updates } : s));
    }
    setUpdating(false);
  }

  const stats = {
    total: members.length,
    pending: members.filter((m) => m.status === 'pending').length,
    paymentValidated: members.filter((m) => m.status === 'payment_validated').length,
    approved: members.filter((m) => m.status === 'approved').length,
  };

  const filtered = members.filter((m) => {
    const matchesSearch = !search ||
      `${m.first_name} ${m.last_name} ${m.email || ''} ${m.country} ${m.city} ${m.member_number || ''}`
        .toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'all' || m.status === statusFilter;
    return matchesSearch && matchesStatus;  
  });
    const ITEMS_PER_PAGE = 10;

const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);

const paginatedMembers = filtered.slice(
  (currentPage - 1) * ITEMS_PER_PAGE,
  currentPage * ITEMS_PER_PAGE
);
  
 

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="pret-gradient text-white">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/15 backdrop-blur flex items-center justify-center"><ShieldCheck className="w-5 h-5" /></div>
              <div>
                <h1 className="text-xl font-display font-bold">Espace Administrateur</h1>
                <p className="text-blue-100 text-sm">Validation des adhésions</p>
              </div>
            </div>
            <button onClick={onExit} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/15 backdrop-blur hover:bg-white/25 transition-all text-sm font-semibold">
              <ArrowLeft className="w-4 h-4" /> Quitter
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard label="Total adhérents" value={stats.total} icon={CheckCircle2} color="blue" />
          <StatCard label="En attente paiement" value={stats.pending} icon={Clock} color="amber" />
          <StatCard label="Paiement validé" value={stats.paymentValidated} icon={ShieldCheck} color="indigo" />
          <StatCard label="Adhésions approuvées" value={stats.approved} icon={CheckCircle2} color="green" />
        </div>

        {/* Controls */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input className="pret-input pl-10" placeholder="Rechercher par nom, email, numéro de membre..." value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <div className="flex gap-2 flex-wrap">
            {(['all', 'pending', 'payment_validated', 'approved', 'rejected'] as StatusFilter[]).map((f) => (
              <button key={f} onClick={() => setStatusFilter(f)}
                className={`px-4 py-2.5 rounded-xl font-semibold text-sm transition-all duration-200 ${statusFilter === f ? 'pret-gradient text-white shadow-lg shadow-blue-600/20' : 'bg-white text-slate-500 border border-slate-200 hover:border-slate-300'}`}>
                {f === 'all' ? 'Tous' : STATUS_LABELS[f]}
              </button>
            ))}
          </div>
        </div>

        {error && <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm mb-4">{error}</div>}

        {loading ? (
          <div className="space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="pret-skeleton h-16 rounded-xl" />)}</div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16">
            <UserCircle className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-400">Aucun adhérent trouvé.</p>
          </div>
        ) : (
          <>
            {/* Desktop */}
            <div className="hidden md:block pret-card overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/50">
                    <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Adhérent</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">N° Membre</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Localisation</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Statut</th>
                    <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedMembers.map((m) => (

                    <tr key={m.id} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <Avatar name={`${m.first_name} ${m.last_name}`} photoUrl={m.id_photo_url} />
                          <div>
                            <p className="font-semibold text-slate-800 text-sm">{m.first_name} {m.last_name}</p>
                            <p className="text-xs text-slate-400">{m.email || m.phone}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        {m.member_number ? (
                          <span className="text-sm font-mono font-semibold text-blue-600">{m.member_number}</span>
                        ) : <span className="text-xs text-slate-300">—</span>}
                      </td>
                      <td className="px-4 py-3"><p className="text-sm text-slate-600">{m.city}, {m.country}</p></td>
                      <td className="px-4 py-3"><StatusBadge status={m.status} /></td>
                      <td className="px-4 py-3 text-right">
                        <button onClick={() => setSelected(m)} className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 text-sm font-semibold hover:bg-blue-100 transition-colors">
                          <Eye className="w-3.5 h-3.5" /> Détails
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="flex items-center justify-between px-4 py-4 border-t border-slate-100">
  <button
    onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
    disabled={currentPage === 1}
    className="px-4 py-2 rounded-lg border border-slate-200 text-sm font-medium disabled:opacity-40"
  >
    ← Précédent
  </button>

  <span className="text-sm text-slate-500">
    Page {currentPage} / {totalPages || 1}
  </span>

  <button
    onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
    disabled={currentPage >= totalPages}
    className="px-4 py-2 rounded-lg border border-slate-200 text-sm font-medium disabled:opacity-40"
  >
    Suivant →
  </button>
</div>
            </div>

            {/* Mobile */}
            <div className="md:hidden space-y-3">
              {filtered.map((m) => (
                <div key={m.id} className="pret-card p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <Avatar name={`${m.first_name} ${m.last_name}`} photoUrl={m.id_photo_url} />
                      <div>
                        <p className="font-semibold text-slate-800 text-sm">{m.first_name} {m.last_name}</p>
                        <p className="text-xs text-slate-400">{m.member_number || 'N° non assigné'}</p>
                      </div>
                    </div>
                    <StatusBadge status={m.status} />
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-slate-500 flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{m.city}, {m.country}</p>
                    <button onClick={() => setSelected(m)} className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 text-sm font-semibold">
                      <Eye className="w-3.5 h-3.5" /> Détails
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

     {selected && (
  <MemberModal
    member={selected}
    onClose={() => setSelected(null)}
    onApprove={() => {
      approveMembership(selected);
      setSelected(null); 
    }}
    onReject={() => {
      rejectMembership(selected);
      setSelected(null);
    }}
    updating={updating}
    onGenerateCard={() => {}}
  />
)}

   
    </div>
  );
}

/* ── Components ───────────────────────────────────────────────── */

function StatCard({ label, value, icon: Icon, color }: { label: string; value: number; icon: React.ComponentType<{ className?: string }>; color: 'amber' | 'blue' | 'indigo' | 'green' }) {
  const colors = { amber: 'bg-amber-50 text-amber-600', blue: 'bg-blue-50 text-blue-600', indigo: 'bg-indigo-50 text-indigo-600', green: 'bg-emerald-50 text-emerald-600' };
  return (
    <div className="pret-card p-4 flex items-center gap-3">
      <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${colors[color]}`}><Icon className="w-5 h-5" /></div>
      <div>
        <p className="text-2xl font-display font-extrabold text-slate-900">{value}</p>
        <p className="text-xs text-slate-400 font-medium">{label}</p>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: Member['status'] }) {
  return <span className={`pret-badge ${STATUS_COLORS[status]}`}>{STATUS_LABELS[status]}</span>;
}

function Avatar({ name, photoUrl }: { name: string; photoUrl?: string | null }) {
  const initials = name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase();
  const [imgError, setImgError] = useState(false);
  if (photoUrl && !imgError) {
    return <img src={photoUrl} alt={name} onError={() => setImgError(true)} className="w-9 h-9 rounded-full object-cover shrink-0 border border-slate-200" />;
  }
  return <div className="w-9 h-9 rounded-full pret-gradient flex items-center justify-center text-white text-xs font-bold shrink-0">{initials}</div>;
}

function MemberModal({ member, onClose, onApprove, onReject, updating, onGenerateCard }: { member: Member; onClose: () => void; onApprove: () => void; onReject: () => void; updating: boolean; onGenerateCard: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in">
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto animate-fade-in-up">
        <div className="pret-gradient text-white p-6 rounded-t-2xl">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              {member.id_photo_url ? (
                <img src={member.id_photo_url} alt={member.first_name} className="w-14 h-14 rounded-xl object-cover border-2 border-white/30" />
              ) : (
                <div className="w-14 h-14 rounded-xl bg-white/15 flex items-center justify-center"><UserCircle className="w-7 h-7" /></div>
              )}
              <div>
                <h2 className="text-xl font-display font-bold">{member.first_name} {member.last_name}</h2>
                <p className="text-blue-100 text-sm">{member.sex}{member.date_of_birth ? ` • ${new Date(member.date_of_birth).toLocaleDateString('fr-FR')}` : ''}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/15 transition-colors"><X className="w-5 h-5" /></button>
          </div>
          <div className="mt-3 flex items-center gap-2 flex-wrap">
            <StatusBadge status={member.status} />
            {member.member_number && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-white/15 text-white border border-white/20">
                <Hash className="w-3 h-3" /> {member.member_number}
              </span>
            )}
          </div>
        </div>

        <div className="p-6 space-y-4">
          <InfoRow icon={Mail} label="Email" value={member.email || '—'} />
          <InfoRow icon={Phone} label="Téléphone" value={member.phone} />
          {member.profession && <InfoRow icon={UserCircle} label="Profession" value={member.profession} />}
          <InfoRow icon={MapPin} label="Localisation" value={`${member.address ? member.address + ', ' : ''}${member.city}, ${member.country}`} />
          {member.voting_location && <InfoRow icon={MapPin} label="Lieu de vote" value={member.voting_location} />}
          <InfoRow icon={CreditCard} label="Paiement" value={`${member.payment_method} — Réf: ${member.payment_reference}`} />
          {member.id_document_type && <InfoRow icon={FileText} label="Type de document" value={`${member.id_document_type} — N° ${member.id_document_number || '—'}`} />}
          <InfoRow icon={Calendar} label="Date d'adhésion" value={new Date(member.created_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })} />

          {member.id_document_url && (
            <div>
              <p className="pret-label">Document d'identité</p>
              {member.id_document_url.endsWith('.pdf') ? (
                <a href={member.id_document_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-100 text-slate-700 text-sm font-semibold hover:bg-slate-200 transition-colors">
                  <FileText className="w-4 h-4" /> Voir le document (PDF)
                </a>
              ) : (
                <img src={member.id_document_url} alt="Document" className="w-full max-w-xs rounded-xl border border-slate-200" />
              )}
            </div>
          )}

          {member.status === 'approved' && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 space-y-3">
              <div className="flex items-center gap-2 text-emerald-700 font-semibold text-sm">
                <CheckCircle2 className="w-4 h-4" /> Adhésion approuvée
              </div>
              {member.member_number && <InfoRow icon={Hash} label="Numéro de membre" value={member.member_number} />}
              {member.qr_code_url && (
                <div>
                  <p className="pret-label">QR Code</p>
                  <img src={member.qr_code_url} alt="QR Code" className="w-32 h-32 rounded-xl border border-slate-200" />
                </div>
              )}
              {member.card_pdf_url && (
                <a href={member.card_pdf_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700 transition-colors">
                  <Download className="w-4 h-4" /> Télécharger la carte de membre
                </a>
              )}
              
            </div>
          )}
        </div>

        {member.status === 'payment_validated' && (
          <div className="p-6 pt-0 flex gap-3">
            <button onClick={onApprove} disabled={updating} className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-all disabled:opacity-50">
              <Check className="w-4 h-4" /> Approuver l'adhésion
            </button>
            <button onClick={onReject} disabled={updating} className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-semibold text-white bg-red-500 hover:bg-red-600 transition-all disabled:opacity-50">
              <Ban className="w-4 h-4" /> Rejeter
            </button>
          </div>
        )}

        {updating && <div className="pb-6 flex justify-center"><Loader2 className="w-5 h-5 animate-spin text-slate-400" /></div>}
      </div>
    </div>
  );
}

function InfoRow({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-9 h-9 rounded-lg bg-slate-100 flex items-center justify-center shrink-0"><Icon className="w-4 h-4 text-slate-500" /></div>
      <div className="min-w-0">
        <p className="text-xs text-slate-400 font-medium">{label}</p>
        <p className="text-sm text-slate-800 font-medium break-words">{value}</p>
      </div>
    </div>
  );
}
