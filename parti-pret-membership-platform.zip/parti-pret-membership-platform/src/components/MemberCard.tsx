import { useRef, useCallback } from 'react';
import QRCode from 'qrcode';
import { X, Download, CreditCard } from 'lucide-react';
import type { Member } from '../lib/supabase';

const CARD_W = 1000;
const CARD_H = 630;
const LOGO_URL = '/images/image.png';

export default function MemberCard({ member, onClose }: { member: Member; onClose: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const verifyUrl = `${window.location.origin}/verify?ref=${encodeURIComponent(member.member_number || member.id)}`;

  const drawRoundedImage = (ctx: CanvasRenderingContext2D, img: HTMLImageElement, x: number, y: number, w: number, h: number, r: number) => {
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(img, x, y, w, h);
    ctx.restore();
  };

  const loadImage = (src: string): Promise<HTMLImageElement> =>
    new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = src;
    });

  const download = useCallback(async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    try {
      canvas.width = CARD_W;
      canvas.height = CARD_H;

      // Background
      const bgGrad = ctx.createLinearGradient(0, 0, CARD_W, CARD_H);
      bgGrad.addColorStop(0, '#0033CC');
      bgGrad.addColorStop(1, '#0b284e');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, CARD_W, CARD_H);

      // Logo
      try {
        const logo = await loadImage(LOGO_URL);
        ctx.save();
        ctx.beginPath();
        ctx.arc(70, 60, 32, 0, Math.PI * 2);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(logo, 38, 28, 64, 64);
        ctx.restore();
      } catch {
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(70, 60, 32, 0, Math.PI * 2);
        ctx.fill();
      }

      // Party name
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px Arial';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText('P.R.E.T', 115, 52);
      ctx.fillStyle = '#93c5fd';
      ctx.font = '13px Arial';
      ctx.fillText("Parti Républicain de l'Équité et la Transparence", 115, 76);

      // Member photo
      const photoX = 50;
      const photoY = 140;
      const photoW = 200;
      const photoH = 240;
      if (member.id_photo_url) {
        try {
          const photo = await loadImage(member.id_photo_url);
          drawRoundedImage(ctx, photo, photoX, photoY, photoW, photoH, 16);
        } catch {
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(photoX, photoY, photoW, photoH);
        }
      } else {
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(photoX, photoY, photoW, photoH);
      }

      // Member info
      const textX = 290;
      let textY = 175;

      ctx.fillStyle = '#94a3b8';
      ctx.font = '12px Arial';
      ctx.fillText('NUMÉRO DE MEMBRE', textX, textY);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 28px Arial';
      ctx.fillText(member.member_number || '—', textX, textY + 30);

      textY += 70;
      ctx.fillStyle = '#94a3b8';
      ctx.font = '12px Arial';
      ctx.fillText('NOM & PRÉNOM', textX, textY);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px Arial';
      ctx.fillText(`${member.last_name.toUpperCase()} ${member.first_name.toUpperCase()}`, textX, textY + 28);

      // QR Code
      const qrSize = 180;
      const qrX = CARD_W - qrSize - 50;
      const qrY = CARD_H - qrSize - 50;

      const qrDataUrl = await QRCode.toDataURL(verifyUrl, {
        width: qrSize,
        margin: 1,
        color: { dark: '#0f172a', light: '#ffffff' },
      });
      const qrImg = await loadImage(qrDataUrl);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(qrX - 8, qrY - 8, qrSize + 16, qrSize + 16);
      ctx.drawImage(qrImg, qrX, qrY, qrSize, qrSize);

      
      const link = document.createElement('a');
      link.download = `carte-militant-${member.member_number || member.id}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();

    } catch (err) {
      console.error(err);
    }
  }, [member, verifyUrl]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl max-w-3xl w-full p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b pb-4 mb-4">
          <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-[#0033CC]" /> Téléchargement direct
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
        </div>

        <div className="flex flex-col items-center gap-4">
          <canvas ref={canvasRef} className="w-full max-w-2xl border rounded-xl shadow-inner bg-slate-50" />
          
          <div className="w-full max-w-xs">
            <button onClick={download} className="w-full bg-green-600 hover:bg-green-700 text-white py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 font-medium transition-all shadow-md">
              <Download className="w-4 h-4" /> Enregistrer la carte
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
