import { useState } from 'react';
import { supabase } from '../lib/supabase';

type InternalLoginProps = {
  onSuccess: (role: 'admin' | 'treasurer') => void;
  onExit: () => void;
};

export default function InternalLogin({
  onSuccess,
  onExit,
}: InternalLoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    setError('');
    setLoading(true);

    try {
      const { data, error: loginError } =
        await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });

      if (loginError) {
        setError('Email ou mot de passe incorrect.');
        return;
      }

      if (!data.user) {
        setError('Impossible de récupérer le compte utilisateur.');
        return;
      }

      const { data: roleData, error: roleError } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', data.user.id)
        .single();

      if (roleError || !roleData) {
        await supabase.auth.signOut();
        setError("Ce compte n'a aucun accès interne.");
        return;
      }

      if (roleData.role !== 'admin' && roleData.role !== 'treasurer') {
        await supabase.auth.signOut();
        setError("Ce compte n'a pas de rôle autorisé.");
        return;
      }

      onSuccess(roleData.role);
    } catch (err) {
      console.error('Erreur de connexion interne :', err);
      setError('Une erreur est survenue. Veuillez réessayer.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
        <h1 className="text-2xl font-display font-extrabold text-slate-900 mb-2">
          Espace interne
        </h1>

        <p className="text-slate-500 mb-6">
          Connexion réservée aux responsables autorisés.
        </p>

        <form onSubmit={handleLogin} className="space-y-5">
          <div>
            <label className="pret-label">Adresse e-mail</label>
            <input
              type="email"
              className="pret-input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
            />
          </div>

          <div>
            <label className="pret-label">Mot de passe</label>
            <input
              type="password"
              className="pret-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="current-password"
            />
          </div>

          {error && (
            <p className="text-sm text-red-600">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-slate-900 text-white py-3 font-semibold disabled:opacity-50"
          >
            {loading ? 'Connexion...' : 'Se connecter'}
          </button>

          <button
            type="button"
            onClick={onExit}
            className="w-full text-slate-600 py-2 font-medium"
          >
            Retour à l'accueil
          </button>
        </form>
      </div>
    </div>
  );
}