import { useEffect, useState, useCallback } from 'react';
import { supabase, type Member, STATUS_LABELS, STATUS_COLORS } from '../lib/supabase';
import {
  Wallet, CheckCircle2, Clock, Search, Eye, X, Check, Ban,
  Loader2, MapPin, Phone, Mail, CreditCard, Calendar, UserCircle,
  ArrowLeft, FileText,
} from 'lucide-react';

export default function TreasurerDashboard({ onExit }: { onExit: () => void }) {
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Member | null>(null);
  const [updating, setUpdating] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  const fetchMembers = useCallback(async () => {
    setLoading(true);
    setError(null);
    const { data, error } = await supabase
      .from('members')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) setError(error.message);
    else setMembers((data as Member[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchMembers(); }, [fetchMembers]);

  async function validatePayment(member: Member, approved: boolean) {
  setUpdating(true);

  const newStatus: Member['status'] = approved
    ? 'payment_validated'
    : 'rejected';

  const { error } = await supabase.rpc('validate_member_payment', {
    p_member_id: member.id,
    p_approved: approved,
  });

  if (!error) {
    const updates = approved
      ? {
          status: newStatus,
          payment_validated_at: new Date().toISOString(),
        }
      : {
          status: newStatus,
        };

    setMembers((ms) =>
      ms.map((m) => (m.id === member.id ? { ...m, ...updates } : m))
    );

    setSelected((s) =>
      s && s.id === member.id ? { ...s, ...updates } : s
    );
  } else {
    console.error('[TreasurerDashboard] Payment validation error:', error);
  }

  setUpdating(false);
}

  const pendingPayments = members.filter((m) => m.status === 'pending');
  const validatedPayments = members.filter((m) => m.status === 'payment_validated');
  const rejectedPayments = members.filter((m) => m.status === 'rejected');

  const filtered = members.filter((m) =>
    !search ||
    `${m.first_name} ${m.last_name} ${m.email || ''} ${m.country} ${m.city} ${m.payment_reference}`
      .toLowerCase().includes(search.toLowerCase())
  );
  const ITEMS_PER_PAGE = 10;

const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);

const paginatedMembers = filtered.slice(
  (currentPage - 1) * ITEMS_PER_PAGE,
  currentPage * ITEMS_PER_PAGE
);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="pret-gradient text-white">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/15 backdrop-blur flex items-center justify-center">
                <Wallet className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-display font-bold">Espace Trésorier</h1>
                <p className="text-blue-100 text-sm">Validation des paiements</p>
              </div>
            </div>
            <button onClick={onExit} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/15 backdrop-blur hover:bg-white/25 transition-all text-sm font-semibold">
              <ArrowLeft className="w-4 h-4" />
              Quitter
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <StatCard label="Paiements en attente" value={pendingPayments.length} icon={Clock} color="amber" />
          <StatCard label="Paiements validés" value={validatedPayments.length} icon={CheckCircle2} color="blue" />
          <StatCard label="Paiements rejetés" value={rejectedPayments.length} icon={Ban} color="red" />
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input className="pret-input pl-10" placeholder="Rechercher par nom, email, référence de paiement..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>

        {error && <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm mb-4">{error}</div>}

        {/* Table */}
        {loading ? (
          <div className="space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="pret-skeleton h-16 rounded-xl" />)}</div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16">
            <UserCircle className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-400">Aucun adhérent trouvé.</p>
          </div>
        ) : (
          <>
            {/* Desktop */}
            <div className="hidden md:block pret-card overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/50">
                    <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Adhérent</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Paiement</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Référence</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Statut</th>
                    <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Action</th>
                  </tr>
                </thead>
                <tbody>
  {paginatedMembers.map((m) => (
    <tr key={m.id} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
      <td className="px-4 py-3">
        <div className="flex items-center gap-3">
          <Avatar
            name={`${m.first_name} ${m.last_name}`}
            photoUrl={m.id_photo_url}
          />
          <div>
            <p className="font-semibold text-slate-800 text-sm">
              {m.first_name} {m.last_name}
            </p>
            <p className="text-xs text-slate-400">{m.phone}</p>
          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3"><span className="text-sm font-medium text-slate-600">{m.payment_method}</span></td>
                      <td className="px-4 py-3"><span className="text-sm text-slate-500 font-mono">{m.payment_reference}</span></td>
                      <td className="px-4 py-3"><StatusBadge status={m.status} /></td>
                      <td className="px-4 py-3 text-right">
                        <button onClick={() => setSelected(m)} className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 text-sm font-semibold hover:bg-blue-100 transition-colors">
                          <Eye className="w-3.5 h-3.5" /> Détails
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
               <div className="flex items-center justify-between px-4 py-4 border-t border-slate-100">
                <button
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="px-4 py-2 rounded-lg border border-slate-200 text-sm font-medium disabled:opacity-40"
                >
                  ← Précédent
                </button>

                <span className="text-sm text-slate-500">
                  Page {currentPage} / {totalPages || 1}
                </span>

                <button
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage >= totalPages}
                  className="px-4 py-2 rounded-lg border border-slate-200 text-sm font-medium disabled:opacity-40"
                >
                  Suivant →
                </button>
              </div>
            </div>

            {/* Mobile */}
            <div className="md:hidden space-y-3">
              {filtered.map((m) => (
                <div key={m.id} className="pret-card p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <Avatar name={`${m.first_name} ${m.last_name}`} photoUrl={m.id_photo_url} />
                      <div>
                        <p className="font-semibold text-slate-800 text-sm">{m.first_name} {m.last_name}</p>
                        <p className="text-xs text-slate-400">{m.payment_method} • {m.payment_reference}</p>
                      </div>
                    </div>
                    <StatusBadge status={m.status} />
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-slate-500 flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{m.city}, {m.country}</p>
                    <button onClick={() => setSelected(m)} className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 text-sm font-semibold">
                      <Eye className="w-3.5 h-3.5" /> Détails
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {selected && (
        <MemberModal
          member={selected}
          onClose={() => setSelected(null)}
          onValidate={(approved) => validatePayment(selected, approved)}
          updating={updating}
        />
      )}
    </div>
  );
}

/* ── Components ───────────────────────────────────────────────── */

function StatCard({ label, value, icon: Icon, color }: { label: string; value: number; icon: React.ComponentType<{ className?: string }>; color: 'amber' | 'blue' | 'red' }) {
  const colors = { amber: 'bg-amber-50 text-amber-600', blue: 'bg-blue-50 text-blue-600', red: 'bg-red-50 text-red-600' };
  return (
    <div className="pret-card p-4 flex items-center gap-3">
      <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${colors[color]}`}><Icon className="w-5 h-5" /></div>
      <div>
        <p className="text-2xl font-display font-extrabold text-slate-900">{value}</p>
        <p className="text-xs text-slate-400 font-medium">{label}</p>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: Member['status'] }) {
  return <span className={`pret-badge ${STATUS_COLORS[status]}`}>{STATUS_LABELS[status]}</span>;
}

function Avatar({ name, photoUrl }: { name: string; photoUrl?: string | null }) {
  const initials = name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase();
  const [imgError, setImgError] = useState(false);
  if (photoUrl && !imgError) {
    return <img src={photoUrl} alt={name} onError={() => setImgError(true)} className="w-9 h-9 rounded-full object-cover shrink-0 border border-slate-200" />;
  }
  return <div className="w-9 h-9 rounded-full pret-gradient flex items-center justify-center text-white text-xs font-bold shrink-0">{initials}</div>;
}

function MemberModal({ member, onClose, onValidate, updating }: { member: Member; onClose: () => void; onValidate: (approved: boolean) => void; updating: boolean }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in">
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto animate-fade-in-up">
        <div className="pret-gradient text-white p-6 rounded-t-2xl">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              {member.id_photo_url ? (
                <img src={member.id_photo_url} alt={member.first_name} className="w-14 h-14 rounded-xl object-cover border-2 border-white/30" />
              ) : (
                <div className="w-14 h-14 rounded-xl bg-white/15 flex items-center justify-center"><UserCircle className="w-7 h-7" /></div>
              )}
              <div>
                <h2 className="text-xl font-display font-bold">{member.first_name} {member.last_name}</h2>
                <p className="text-blue-100 text-sm">{member.sex}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/15 transition-colors"><X className="w-5 h-5" /></button>
          </div>
          <div className="mt-3"><StatusBadge status={member.status} /></div>
        </div>

        <div className="p-6 space-y-4">
          <InfoRow icon={Mail} label="Email" value={member.email || '—'} />
          <InfoRow icon={Phone} label="Téléphone" value={member.phone} />
          <InfoRow icon={MapPin} label="Localisation" value={`${member.address ? member.address + ', ' : ''}${member.city}, ${member.country}`} />
          <InfoRow icon={CreditCard} label="Paiement" value={`${member.payment_method} — Réf: ${member.payment_reference}`} />
          <InfoRow icon={Calendar} label="Date d'adhésion" value={new Date(member.created_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })} />
          {member.id_document_url && (
            <div>
              <p className="pret-label">Document d'identité</p>
              {member.id_document_url.endsWith('.pdf') ? (
                <a href={member.id_document_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-100 text-slate-700 text-sm font-semibold hover:bg-slate-200 transition-colors">
                  <FileText className="w-4 h-4" /> Voir le document (PDF)
                </a>
              ) : (
                <img src={member.id_document_url} alt="Document" className="w-full max-w-xs rounded-xl border border-slate-200" />
              )}
            </div>
          )}
        </div>

        {member.status === 'pending' && (
          <div className="p-6 pt-0 flex gap-3">
            <button onClick={() => onValidate(true)} disabled={updating} className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-semibold text-white bg-blue-600 hover:bg-blue-700 transition-all disabled:opacity-50">
              <Check className="w-4 h-4" /> Valider le paiement
            </button>
            <button onClick={() => onValidate(false)} disabled={updating} className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-semibold text-white bg-red-500 hover:bg-red-600 transition-all disabled:opacity-50">
              <Ban className="w-4 h-4" /> Rejeter
            </button>
          </div>
        )}

        {updating && <div className="pb-6 flex justify-center"><Loader2 className="w-5 h-5 animate-spin text-slate-400" /></div>}
      </div>
    </div>
  );
}

function InfoRow({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-9 h-9 rounded-lg bg-slate-100 flex items-center justify-center shrink-0"><Icon className="w-4 h-4 text-slate-500" /></div>
      <div className="min-w-0">
        <p className="text-xs text-slate-400 font-medium">{label}</p>
        <p className="text-sm text-slate-800 font-medium break-words">{value}</p>
      </div>
    </div>
  );
}
