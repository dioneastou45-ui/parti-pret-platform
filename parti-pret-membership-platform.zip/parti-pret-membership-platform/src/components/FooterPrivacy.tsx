import React, { useState } from 'react';

export function FooterPrivacy() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* SECTION FOOTER COMPACTE */}
      <footer className="w-full bg-slate-900 text-slate-400 py-8 text-center text-sm border-t border-slate-800">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p>&copy; {new Date().getFullYear()} Parti PRET. Tous droits réservés.</p>
          <button 
            onClick={() => setIsOpen(true)} 
            className="hover:text-white underline font-medium transition-colors"
          >
            Politique de Confidentialité (Loi n°2008-12)
          </button>
        </div>
      </footer>

      {/* MODAL DE SÉCURITÉ JURIDIQUE SOUVERAINE (CDP) */}
      {isOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 text-slate-300 max-w-2xl w-full max-h-[80vh] overflow-y-auto rounded-xl p-6 text-left shadow-2xl">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3 mb-4">
              <h3 className="text-lg font-bold text-white">Politique de Confidentialité - P.R.E.T</h3>
              <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-white text-xl font-bold">×</button>
            </div>
            
            <div className="space-y-4 text-xs sm:text-sm leading-relaxed overflow-y-auto pr-2">
              <p className="font-semibold text-blue-400">La présente politique de confidentialité est établie conformément aux dispositions de la Loi n°2008-12 du 25 janvier 2008 relative à la protection des données à caractère personnel.</p>
              <p>Les données personnelles collectées sont traitées uniquement pour des finalités précises, explicites et légitimes. Elles servent notamment à la gestion des adhésions, à l’organisation et au fonctionnement interne du Parti, à la communication avec les membres, à la gestion des cotisations ainsi qu’à l’application du règlement intérieur.</p>
              <p>Certaines données peuvent être utilisées dans le cadre des procédures disciplinaires prévues aux articles 27 à 30 du règlement intérieur. Elles permettent de constater des manquements, d’instruire les dossiers et de prendre des décisions par les instances compétentes. Ces procédures sont conduites dans le respect des droits de la défense et du principe du contradictoire.</p>
              <p>L’inscription sur la plateforme d’adhésion vaut consentement libre, spécifique, éclairé et univoque au traitement des données personnelles. Ce consentement est recueilli lors de la validation de l’inscription et peut être conservé à des fins de preuve.</p>
              <p>L’accès aux données personnelles est STRICTEMENT réservé aux personnes habilitées au sein du Parti. Il peut également être accordé à des prestataires techniques intervenant pour son compte. Dans tous les cas, ces accès sont soumis à une obligation stricte de confidentialité. Les données ne sont ni vendues, ni cédées, ni communiquées à des tiers.</p>
              <p>Le P.R.E.T met en œuvre des mesures techniques et organisationnelles appropriées afin d’assurer la sécurité et la confidentialité des données. Ces mesures visent à prévenir tout accès non autorisé, toute perte, toute altération ou toute divulgation.</p>
              <p>Les données personnelles sont conservées pendant toute la durée de l’adhésion. À la fin de celle-ci, elles peuvent être archivées pour une durée n’excédant pas de cinq (5) ans. Cette durée constitue un seuil maximal. Elle peut être réduite en fonction des besoins ou des obligations applicables. À l’expiration de ce délai, le Parti doit notifier la personne concernée de la poursuite éventuelle du traitement de ses données. Cette notification précise à nouveau les finalités de cette utilisation.</p>
              <p>En cas de refus exprimé par la personne concernée, ses données sont supprimées ou anonymisées dans les meilleurs délais, conformément aux dispositions légales applicables.</p>
              <p>Conformément à la législation en vigueur, chaque membre dispose d’un droit d’accès, de rectification, d’opposition et de suppression de ses données personnelles. Ces droits peuvent être exercés auprès du P.R.E.T aux coordonnées indiquées ci-après.</p>
              <p>En cas de litige relatif au traitement des données personnelles, le membre peut saisir la Commission de Protection des Données Personnelles (CDP) du Sénégal.</p>
              <p>La plateforme peut utiliser des cookies ou des technologies similaires nécessaires à son bon fonctionnement, à la sécurité des accès et à l’amélioration de l’expérience utilisateur.</p>
              <p>Le P.R.E.T se réserve le droit de modifier la présente politique de confidentialité à tout moment. Toute modification importante fera l’objet d’une information appropriée.</p>
              <p className="pt-2 border-t border-slate-800 text-xs text-slate-400">Pour toute question relative à la protection des données personnelles, les utilisateurs peuvent contacter le P.R.E.T à l’adresse suivante : <span className="text-blue-400 font-mono">contact@pret.sn</span></p>
            </div>

            <div className="mt-6 flex justify-end">
              <button 
                onClick={() => setIsOpen(false)} 
                className="bg-blue-600 hover:bg-blue-500 text-white font-semibold px-4 py-2 rounded-lg transition-colors"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
