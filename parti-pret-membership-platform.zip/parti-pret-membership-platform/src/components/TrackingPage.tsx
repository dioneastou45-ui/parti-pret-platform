import { useState } from 'react';
import { supabase, type Member, STATUS_LABELS, STATUS_COLORS } from '../lib/supabase';
import {
  Search, Loader2, AlertCircle, ArrowLeft, CheckCircle2,
  Clock, ShieldCheck, XCircle, Hash, QrCode, Download,
  Phone, MapPin, Calendar, User,
} from 'lucide-react';

export default function TrackingPage({ onExit }: { onExit: () => void }) {
  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [result, setResult] = useState<Member | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [searched, setSearched] = useState(false);

  async function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (!query.trim()) return;
    setSearching(true);
    setError(null);
    setResult(null);
    setSearched(false);

    const { data, error } = await supabase.rpc('track_membership', {
  p_query: query.trim(),
});

if (error) {
  console.error('[TrackingPage] Tracking error:', error);
  setError('Une erreur est survenue lors de la recherche. Veuillez réessayer.');
} else if (data && data.length > 0) {
  setResult(data[0] as Member);
} else {
  setError(
    'Aucune adhésion trouvée. Vérifiez votre numéro de téléphone ou votre numéro de membre.'
  );
}

setSearching(false);
setSearched(true);
  }

  return (
    <div className="min-h-screen pret-gradient-soft">
      {/* Header */}
      <div className="pret-gradient text-white">
        <div className="max-w-3xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/15 backdrop-blur flex items-center justify-center">
                <Search className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-display font-bold">Suivi d'adhésion</h1>
                <p className="text-blue-100 text-sm">Vérifiez le statut de votre demande</p>
              </div>
            </div>
            <button onClick={onExit} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/15 backdrop-blur hover:bg-white/25 transition-all text-sm font-semibold">
              <ArrowLeft className="w-4 h-4" /> Accueil
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8">
        {/* Search */}
        <div className="pret-card p-6 md:p-8 mb-6 animate-fade-in-up">
          <h2 className="text-lg font-display font-bold text-slate-900 mb-2">Suivez votre demande</h2>
          <p className="text-sm text-slate-500 mb-4">
            Saisissez votre numéro de téléphone ou votre numéro de membre pour vérifier le statut de votre adhésion.
          </p>
          <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                className="pret-input pl-10"
                placeholder="Ex: +221 77 123 45 67 ou PRET-2026-ABC123"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
            <button type="submit" disabled={searching} className="pret-btn-primary">
              {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              Rechercher
            </button>
          </form>
        </div>

        {/* Error */}
        {error && (
          <div className="pret-card p-6 text-center animate-fade-in-up">
            <AlertCircle className="w-10 h-10 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500">{error}</p>
          </div>
        )}

        {/* Result */}
        {result && <ResultCard member={result} />}

        {/* Empty state */}
        {searched && !result && !error && (
          <div className="pret-card p-6 text-center animate-fade-in-up">
            <AlertCircle className="w-10 h-10 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500">Aucune adhésion trouvée.</p>
          </div>
        )}

        {/* Process timeline */}
        {!searched && (
          <div className="pret-card p-6 md:p-8 animate-fade-in-up" style={{ animationDelay: '0.05s' }}>
            <h3 className="font-display font-bold text-slate-900 mb-4">Le parcours d'adhésion</h3>
            <div className="space-y-4">
              {[
                { icon: Clock, label: 'En attente de paiement', desc: 'Votre demande est enregistrée, en attente de validation par le Trésorier.', color: 'amber' },
                { icon: ShieldCheck, label: 'Paiement validé', desc: 'Le Trésorier a validé votre paiement. En attente de validation par l\'Administrateur.', color: 'blue' },
                { icon: CheckCircle2, label: 'Adhésion approuvée', desc: 'Votre adhésion est confirmée. Votre numéro de membre, QR code et carte sont générés.', color: 'emerald' },
              ].map((step, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 bg-${step.color}-50 text-${step.color}-600`}>
                    <step.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-semibold text-slate-800 text-sm">{step.label}</p>
                    <p className="text-sm text-slate-500">{step.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}


function ResultCard({ member }: { member: Member }) {
  return (
    <div className="pret-card overflow-hidden animate-fade-in-up">
      {/* Header */}
      <div className="pret-gradient text-white p-6">
        <div className="flex items-center gap-3 mb-4">
          {member.id_photo_url ? (
            <img src={member.id_photo_url} alt="" className="w-16 h-16 rounded-xl object-cover border-2 border-white/30" />
          ) : (
            <div className="w-16 h-16 rounded-xl bg-white/15 flex items-center justify-center"><User className="w-8 h-8" /></div>
          )}
          <div>
            <h2 className="text-xl font-display font-bold">{member.first_name} {member.last_name}</h2>

          </div>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <span className={`pret-badge ${STATUS_COLORS[member.status]} bg-white`}>{STATUS_LABELS[member.status]}</span>
          {member.member_number && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-white/15 text-white border border-white/20 font-mono">
  <Hash className="w-3 h-3" /> ******{member.member_number ? member.member_number.slice(-4) : ''}
</span>

          )}
        </div>
      </div>

      {/* Body */}
      <div className="p-6 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <InfoRow icon={Calendar} label="Date de demande" value={new Date(member.created_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })} />
          {member.payment_validated_at && (
            <InfoRow icon={CheckCircle2} label="Paiement validé le" value={new Date(member.payment_validated_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })} />
          )}
          {member.membership_validated_at && (
            <InfoRow icon={ShieldCheck} label="Adhésion validée le" value={new Date(member.membership_validated_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })} />
          )}
        </div>

        {/* Approved: show QR + card */}
        {member.status === 'approved' && (
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 space-y-3">
            <div className="flex items-center gap-2 text-emerald-700 font-semibold text-sm">
              <CheckCircle2 className="w-4 h-4" /> Votre adhésion est confirmée !
            </div>
            {member.qr_code_url && (
              <div className="flex flex-col items-center gap-2">
                <img src={member.qr_code_url} alt="QR Code" className="w-40 h-40 rounded-xl border border-emerald-200 bg-white p-2" />
                <p className="text-xs text-slate-500">Scannez ce QR code pour vérifier votre adhésion</p>
              </div>
            )}
            {member.card_pdf_url && (
              <a href={member.card_pdf_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700 transition-colors w-full justify-center">
                <Download className="w-4 h-4" /> Télécharger la carte de membre (PDF)
              </a>
            )}
            {!member.qr_code_url && !member.card_pdf_url && (
              <p className="text-xs text-slate-400 flex items-center gap-1.5">
                <QrCode className="w-3.5 h-3.5" /> QR code et carte de membre en cours de génération...
              </p>
            )}
          </div>
        )}

        {/* Rejected */}
        {member.status === 'rejected' && (
          <div className="p-4 rounded-xl bg-red-50 border border-red-200">
            <div className="flex items-center gap-2 text-red-700 font-semibold text-sm">
              <XCircle className="w-4 h-4" /> Votre demande a été rejetée.
            </div>
            <p className="text-sm text-slate-500 mt-1">Pour plus d'informations, contactez le bureau du Parti PRET.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function InfoRow({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-9 h-9 rounded-lg bg-slate-100 flex items-center justify-center shrink-0"><Icon className="w-4 h-4 text-slate-500" /></div>
      <div className="min-w-0">
        <p className="text-xs text-slate-400 font-medium">{label}</p>
        <p className="text-sm text-slate-800 font-medium break-words">{value}</p>
      </div>
    </div>
  );
}
