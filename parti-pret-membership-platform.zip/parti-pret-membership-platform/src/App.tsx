import { useState } from 'react';
import InternalLogin from './components/InternalLogin';
import LandingPage from './components/LandingPage';
import MembershipForm from './components/MembershipForm';
import AdminDashboard from './components/AdminDashboard';
import TreasurerDashboard from './components/TreasurerDashboard';
import TrackingPage from './components/TrackingPage';

type View = 'landing' | 'form' | 'admin' | 'treasurer' | 'track' | 'internal';

export default function App() {
  const [view, setView] = useState<View>('landing');
  const isInternalPath = window.location.pathname === '/espace-interne';
  if (isInternalPath && view === 'landing') {
  return (
    <InternalLogin
      onSuccess={(role) => setView(role)}
      onExit={() => {
        window.history.pushState({}, '', '/');
        setView('landing');
      }}
    />
  );
}

  if (view === 'form') return <MembershipForm onDone={() => setView('landing')} />;
  if (view === 'internal') {
  return (
    <InternalLogin
      onSuccess={(role) => setView(role)}
      onExit={() => setView('landing')}
    />
  );
}
  if (view === 'admin') return <AdminDashboard onExit={() => setView('landing')} />;
  if (view === 'treasurer') return <TreasurerDashboard onExit={() => setView('landing')} />;
  if (view === 'track') return <TrackingPage onExit={() => setView('landing')} />;

  return (
  <LandingPage
    onJoin={() => setView('form')}
    onAdmin={() => setView('internal')}
    onTreasurer={() => setView('internal')}
    onTrack={() => setView('track')}
  />
);
}
