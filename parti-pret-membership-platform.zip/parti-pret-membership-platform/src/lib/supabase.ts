import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;


export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type MemberStatus = 'pending' | 'payment_validated' | 'approved' | 'rejected';
export type PaymentMethod = 'Wave' | 'Orange Money';
export type IdDocType = 'CNI' | 'Passeport' | 'Permis de conduire' | 'Autre';

export type Member = {
  id: string;
  first_name: string;
  last_name: string;
  sex: 'Homme' | 'Femme' | 'Autre';
  date_of_birth: string | null;
  phone: string;
  email: string | null;
  profession: string | null;
  country: string;
  city: string;
  address: string | null;
  voting_location: string | null;
  political_section: string | null;
  id_photo_url: string | null;
  id_document_url: string | null;
  id_document_type: IdDocType | null;
  id_document_number: string | null;
  payment_method: PaymentMethod;
  payment_reference: string;
  consent_accepted: boolean;
  status: MemberStatus;
  member_number: string | null;
  qr_code_url: string | null;
  card_pdf_url: string | null;
  payment_validated_at: string | null;
  membership_validated_at: string | null;
  created_at: string;
  
  region: string | null;
};

export type MemberInput = {
  first_name: string;
  last_name: string;
  sex: Member['sex'];
  date_of_birth: string | null;
  phone: string;
  email: string | null;
  profession: string | null;
  country: string;
  city: string;
  
  address: string | null;
  voting_location: string | null;
  political_section: string | null;
  id_photo_url: string | null;
  id_document_url: string | null;
  id_document_type: IdDocType | null;
  id_document_number: string | null;
  payment_method: PaymentMethod;
  payment_reference: string;
  consent_accepted: boolean;
};

export const STATUS_LABELS: Record<MemberStatus, string> = {
  pending: 'En attente de paiement',
  payment_validated: 'Paiement validé',
  approved: 'Adhésion approuvée',
  rejected: 'Rejeté',
};

export const STATUS_COLORS: Record<MemberStatus, string> = {
  pending: 'bg-amber-50 text-amber-700 border-amber-200',
  payment_validated: 'bg-blue-50 text-blue-700 border-blue-200',
  approved: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  rejected: 'bg-red-50 text-red-700 border-red-200',
};

export function generateMemberNumber(): string {
  const year = new Date().getFullYear();
  const random = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `PRET-${year}-${random}`;
}
