import { Resend } from 'resend';


const resend = new Resend((import.meta as any).env.VITE_RESEND_API_KEY);

export async function envoyerEmailCarteMilitant(
  emailMilitant: string, 
  nomMilitant: string, 
  matricule: string, 
  urlCartePdf: string
) {
  try {
   const { error } = await resend.emails.send({

      from: 'P.R.E.T <onboarding@resend.dev>', 
      to: emailMilitant.trim().toLowerCase(),
      subject: '🎉 Bienvenue au P.R.E.T - Votre carte de membre officielle',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 25px; border: 1px solid #f1f5f9; border-radius: 12px;">
          <h2 style="color: #0033CC;">Félicitations ${nomMilitant} !</h2>
          <p>Votre adhésion au <strong>Parti Républicain de l'Équité et la Transparence (P.R.E.T)</strong> a été officiellement approuvée.</p>
          
          <div style="background-color: #f8fafc; padding: 15px; border-radius: 8px; margin: 20px 0; text-align: center;">
            <p style="margin: 0; font-size: 12px; color: #64748b; font-weight: bold; text-transform: uppercase;">Votre numéro matricule officiel :</p>
            <p style="margin: 5px 0 0 0; font-size: 18px; font-weight: bold; color: #0033CC; font-family: monospace;">${matricule}</p>
          </div>

          <p>Vous pouvez télécharger votre carte de membre officielle au format PDF en cliquant ci-dessous :</p>
          
          <div style="text-align: center; margin: 25px 0;">
            <a href="${urlCartePdf}" target="_blank" style="display: inline-block; background-color: #0033CC; color: white; font-weight: bold; padding: 12px 24px; text-decoration: none; border-radius: 8px;">
              TÉLÉCHARGER MA CARTE (PDF)
            </a>
          </div>

          <p style="font-size: 11px; color: #94a3b8; margin-top: 30px; border-top: 1px solid #e2e8f0; padding-top: 15px; text-align: center;">
            "L'Être Humain au cœur de la République"
          </p>
        </div>
      `
    });

    if (error) {
      console.error("Erreur Resend :", error);
      return false;
    }
    return true;
  } catch (err) {
    console.error("Erreur technique email :", err);
    return false;
  }
}
