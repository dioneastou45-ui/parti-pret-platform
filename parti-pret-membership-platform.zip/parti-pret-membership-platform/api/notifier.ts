import { Resend } from 'resend';

declare const process: any;

const resend = new Resend(process.env.RESEND_API_KEY);

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Méthode non autorisée' });
  }

  try {
    const { first_name, last_name, phone, email, payment_method, payment_reference } = req.body;

    await resend.emails.send({
      from: 'Parti PRET <ne-pas-repondre@adhesion.pret.sn>',
      to: ['aliounecoulyma@gmail.com', 'contact.info.pret@gmail.com'], 
      subject: `🚨 [NEW] Adhésion à vérifier : ${payment_reference}`,
      html: `
        <h3>📥 Nouvelle demande d'adhésion enregistrée (Statut : En attente)</h3>
        <p><strong>Militant :</strong> ${first_name.toUpperCase()} ${last_name.toUpperCase()}</p>
        <p><strong>Téléphone :</strong> ${phone}</p>
        <p><strong>E-mail :</strong> ${email || 'Non renseigné'}</p>
        <p><strong>Moyen de paiement :</strong> ${payment_method}</p>
        <p><strong>Référence de paiement :</strong> <strong style="color: #dc2626; font-size: 1.2em; background-color: #fef2f2; padding: 2px 6px; border: 1px solid #fee2e2; border-radius: 4px;">${payment_reference}</strong></p>
        <br />
        <hr />
        <p style="color: #4b5563; font-style: italic;">👉 Action requise : Veuillez vérifier la bonne réception des fonds sur votre terminal ${payment_method} avant de valider la fiche dans l'espace administration du parti PRET.</p>
      `,
    });

    return res.status(200).json({ message: 'Alerte transmise avec succès !' });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
}
